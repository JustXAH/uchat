#include "libmx.h"

bool mx_is_odd(int value) {
    return (value % 2 == 0) ? 0 : 1;
}
