#include <stdbool.h>

bool mx_islower(int c) {
    return (c > 96 && c < 123) ? 1 : 0;
}
