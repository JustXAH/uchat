#include "libmx.h"

bool mx_isdigit(int c) {
    return (c > 47 && c < 58) ? 1 : 0;
}
